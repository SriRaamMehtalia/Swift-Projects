//
//  ViewController.swift
//  TallyHo-2
//
//  Created by Mehtalia, SriRaam '17 on 2/10/17.
//  Copyright © 2017 smeth. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var c1: UILabel!
    @IBOutlet weak var c2: UILabel!
    @IBOutlet weak var c3: UILabel!
    
    var clicks1 : Int16 = 0
    var clicks2 : Int16 = 0
    var clicks3 : Int16 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        enum PathChoice {
            case store
            case retreive
            case update
        }
        

        let path = PathChoice.retreive
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        if(path == PathChoice.store) {
            
            let aCount = NSEntityDescription.insertNewObject(forEntityName: "Counter", into: context)
        
            aCount.setValue(0, forKey: "clicks1")
            aCount.setValue(0, forKey: "clicks2")
            aCount.setValue(0, forKey: "clicks3")
            
            do{
                try context.save()
                print("=========Counter Saved!===========")
            }
            catch {
                print("oops")
            }
            
            
        }
        else if path == PathChoice.retreive {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Counter")
            do {
                let results = try context.fetch(request)
                
                if( results.count > 0) {
                    for result in results as! [NSManagedObject] {
                        if let cou1 = result.value(forKey: "clicks1") as? Int16 {
                            let cou2 = result.value(forKey: "clicks2") as? Int16
                            let cou3 = result.value(forKey: "clicks3") as? Int16
                            
                            print( "Updating: First: \(cou1) Second: \(cou2!) Third: \(cou3!)")

                        }
                    }
                }
            } catch {
                print(" ooooooooooooooooops ")
            }
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func inc1(_ sender: Any) {
        clicks1 += 1
        
        c1.text = "\(clicks1) clicks!"
    }
    
    @IBAction func reset1(_ sender: Any) {
        clicks1 = 0
        c1.text = "unclicked"
    }
    
    @IBAction func inc2(_ sender: Any) {
        clicks2 += 1
        c2.text = "\(clicks2) clicks!"
    }
    
    @IBAction func reset2(_ sender: Any) {
        clicks2 = 0
        c2.text = "unclicked"
    }
    
    @IBAction func inc3(_ sender: Any) {
        clicks3 += 1
        c3.text = "\(clicks3) clicks!"
    }
    
    @IBAction func reset3(_ sender: Any) {
        clicks3 = 0
        c3.text = "unclicked"
    }
    
    
    
    

}

