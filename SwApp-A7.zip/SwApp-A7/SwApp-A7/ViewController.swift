//
//  ViewController.swift
//  SwApp-A7
//
//  Created by Dylan Doblar on 2/1/17.
//  Copyright © 2017 dylandoblar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var webView1: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let myUrl = NSURL(string: "https://www.geofortomorrow.org/newsview/")
        let httpRequest = NSURLRequest(url: myUrl as! URL)
        webView1.loadRequest(httpRequest as URLRequest)
        NSLog("Loading \(myUrl)")
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

