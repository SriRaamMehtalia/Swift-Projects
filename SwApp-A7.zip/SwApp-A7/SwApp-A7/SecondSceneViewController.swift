//
//  SecondSceneViewController.swift
//  SwApp-A7
//
//  Created by Dylan Doblar on 2/1/17.
//  Copyright © 2017 dylandoblar. All rights reserved.
//

import UIKit

class SecondSceneViewController: UIViewController {
    @IBOutlet var webView2: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let myUrl = NSURL(string: "https://www.geofortomorrow.org/newsview/app.html")
        let httpRequest = NSURLRequest(url: myUrl as! URL)
        webView2.loadRequest(httpRequest as URLRequest)
        NSLog("Loading \(myUrl)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
