//
//  ViewController.swift
//  KeychainMehtalia
//
//  Created by Mehtalia, SriRaam '17 on 4/4/17.
//  Copyright © 2017 smeth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lable: UILabel!
    
    
    @IBOutlet weak var secret: UITextView!
    
    @IBOutlet weak var buttonview: UIButton!
    
    @IBAction func authenticateTapped(_ sender: Any) {
        unlockSecretMessage()
        lable.text = "Type your secret below!"
        buttonview.isHidden = false
    }
    
    
    @IBAction func logout(_ sender: Any) {
        
        secret.isHidden = true
        lable.text = "Nothing to see here"
        buttonview.isHidden = true
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        title = "Nothing to see here"
        
        lable.text = title
        
        secret.isHidden = true
        
        buttonview.isHidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func unlockSecretMessage() {
        secret.isHidden = false
        title = "Secret stuff!"
        
        if let text = KeychainWrapper.standardKeychainAccess().string(forKey: "SecretMessage") {
            secret.text = text
        }
    }
    
    func saveSecretMessage() {
        if !secret.isHidden {
            _ = KeychainWrapper.standardKeychainAccess().setString(secret.text, forKey: "SecretMessage")
            secret.resignFirstResponder()
            secret.isHidden = true
            title = "Nothing to see here"
        }
    }
    
  

}

