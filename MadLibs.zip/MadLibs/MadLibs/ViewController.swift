//
//  ViewController.swift
//  MadLibs
//
//  Created by Mehtalia, SriRaam '17 on 1/30/17.
//  Copyright © 2017 smeht. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let genStory = "One bright day, a <noun1> was just <verb1> when he ran into a big guy named Donald. He offered <noun1> a job as a <job1>; he was thrilled, and <adjective1>. He ran all the way home to his house in <place1> and told his best buddy, a <noun2>, the great news!"
    
    @IBOutlet weak var noun1: UITextField!
    
    @IBOutlet weak var verb1: UITextField!
    
    @IBOutlet weak var job1: UITextField!
    
    @IBOutlet weak var adjective1: UITextField!
    
    @IBOutlet weak var place1: UITextField!
    
    @IBOutlet weak var noun2: UITextField!
    
    @IBOutlet weak var textArea: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func createStory(sender: AnyObject) {
        var story = genStory
        
        story = story.stringByReplacingOccurrencesOfString("<noun1>", withString: noun1.text! )
        
        story = story.stringByReplacingOccurrencesOfString("<verb1>", withString: verb1.text! )
        
        story = story.stringByReplacingOccurrencesOfString("<job1>", withString: job1.text! )
        
        story = story.stringByReplacingOccurrencesOfString("<place1>", withString: place1.text! )
        
        story = story.stringByReplacingOccurrencesOfString("<adjective1>", withString: adjective1.text!)
        
        story = story.stringByReplacingOccurrencesOfString("<noun2>", withString: noun2.text! )
        
        textArea.text = story
    }
}

