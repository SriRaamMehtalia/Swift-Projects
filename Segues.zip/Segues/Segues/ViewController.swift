//
//  ViewController.swift
//  Segues
//
//  Created by Sean Costello on 2/3/17.
//  Copyright © 2017 cost. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let url = NSURL(string: "https://www.google.com")
        let httpRequest = NSURLRequest(url: url as! URL)
        firstView.loadRequest(httpRequest as URLRequest)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

