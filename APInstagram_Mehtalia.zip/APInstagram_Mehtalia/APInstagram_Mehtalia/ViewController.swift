//
//  ViewController.swift
//  APInstagram_Mehtalia
//
//  Created by Mehtalia, SriRaam '17 on 4/5/17.
//  Copyright © 2017 smeth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

