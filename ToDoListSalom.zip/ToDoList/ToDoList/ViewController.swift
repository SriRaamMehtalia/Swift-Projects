//
//  ViewController.swift
//  ToDoList
//
//  Created by Trevor Salom on 2/27/17.
//  Copyright © 2017 Trevor Salom. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var sList : [String] = [];
    
    @IBOutlet weak var list: UITableView?
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sList.count
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            sList.remove(at: indexPath.row)
            UserDefaults.standard.setValue(sList, forKey: "todolist")
            list?.reloadData()
        }
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "protoCell");
        var parts = sList[indexPath.row].characters.split(separator: "_").map(String.init)
        cell.textLabel?.text = parts[0]
        if(parts[1] == "2") { cell.backgroundColor = UIColor.red }
        else if(parts[1] == "1") { cell.backgroundColor = UIColor.yellow }
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(UserDefaults.standard.array(forKey: "todolist") != nil) {
            sList = UserDefaults.standard.array(forKey: "todolist") as! [String]
        }
        else {
            UserDefaults.standard.setValue([], forKey: "todolist")
            sList = []
        }
        self.list?.reloadData();
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

