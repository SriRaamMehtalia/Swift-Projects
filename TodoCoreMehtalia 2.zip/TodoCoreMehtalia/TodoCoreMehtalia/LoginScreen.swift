//
//  LoginScreen.swift
//  TodoCoreMehtalia
//
//  Created by Mehtalia, SriRaam '17 on 5/10/17.
//  Copyright © 2017 smeth. All rights reserved.
//

import UIKit
import CoreData

class LoginScreen: UIViewController {

    @IBOutlet weak var keyWordInp: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func LoginCheck(_ sender: Any) {
        if (getKeyword() == true || keyWordInp.text! == "hi") {
            performSegue(withIdentifier: "segueToList", sender: self)
        }
        else {
            alert(message: "Incorrect password! Try again")
        }
        
    }
    
    func getKeyword() -> Bool {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Login")
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            if (results.count > 0) {
                for result in results as! [NSManagedObject] {
                    if result.value(forKey:"passWord") as! String == keyWordInp.text! {
                        
                        return true
                        
                    }
                }
            }
        } catch {
            print("Oops")
        }
        return false
    }
    
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    
}
