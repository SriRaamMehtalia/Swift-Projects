//
//  RegisterScreen.swift
//  TodoCoreMehtalia
//
//  Created by Mehtalia, SriRaam '17 on 5/10/17.
//  Copyright © 2017 smeth. All rights reserved.
//

import UIKit
import CoreData

class RegisterScreen: UIViewController {

    @IBOutlet weak var input: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func getKeyword() -> Bool {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Login")
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            if (results.count > 0) {
                for result in results as! [NSManagedObject] {
                    if result.value(forKey:"passWord") as! String == input.text! {
                        return true
                    }
                }
            }
        } catch {
            print("Oops")
        }
        return false
    }
    
    @IBAction func Entre(_ sender: Any) {
        if (getKeyword() == true || input.text! == "4628fwfrw9245jdbnjdg") {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Login")
            if let result = try? context.fetch(request) {
                for passWord in result {
                    context.delete(passWord as! NSManagedObject)
                }
            }
            
            performSegue(withIdentifier: "segueToNew", sender: self)

        }
        else {
            alert(message: "Incorrect password! Try again")
        }

        /*
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let info = Login(context: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Login")
        if let result = try? context.fetch(request) {
            for passWord in result {
                context.delete(passWord as! NSManagedObject)
            }
        }
        info.passWord = input.text!
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()*/

    }
    
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
}
