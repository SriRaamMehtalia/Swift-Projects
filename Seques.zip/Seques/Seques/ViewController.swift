//
//  ViewController.swift
//  Seques
//
//  Created by Mehtalia, SriRaam '17 on 2/1/17.
//  Copyright © 2017 smeht. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var webView1: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = NSURL(string: "https://twitter.com")
        let httpRequest = NSURLRequest(URL: url!)
        webView1.loadRequest(httpRequest)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    

}

