//
//  AddTaskViewController.swift
//  ToDoListCoreData_Ravishanker
//
//  Created by Pravin Ravishanker on 2/18/17.
//  Copyright © 2017 ravishanker. All rights reserved.
//

import UIKit
import CoreData

class AddTaskViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var priority: UITextField!
    @IBOutlet weak var isImp: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func addTask(_ sender: Any) {
        enum PathChoice {
            case store
            case retrieve
            case update
        }
        
        let path = PathChoice.store
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        if (path == PathChoice.store) {
            let newTask = NSEntityDescription.insertNewObject(forEntityName: "Task", into: context)
            newTask.setValue(textField.text, forKey: "name")
            newTask.setValue(Int(priority.text!), forKey: "priority")
            newTask.setValue(isImp.isOn, forKey: "isImportant")
            do {
                try context.save()
            } catch {
                print ("oops")
            }
        }
        navigationController!.popViewController(animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
