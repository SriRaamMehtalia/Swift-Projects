//
//  ViewController.swift
//  ToDoListCoreData_Ravishanker
//
//  Created by Pravin Ravishanker on 2/18/17.
//  Copyright © 2017 ravishanker. All rights reserved.
//

import UIKit
import CoreData
import Foundation


struct Task {
    var task_name: String
    var priority: Int
}


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var List_of_Tasks : [(String,Int)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        getData()
        tableView.reloadData()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /*
        var numberofRows = 0
        enum PathChoice {
            case store
            case retrieve
            case update
        }
        let path = PathChoice.retrieve
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
                if (path == PathChoice.retrieve) {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Task")
            request.returnsObjectsAsFaults = false
            do {
                let results = try context.fetch(request)
                
                if (results.count > 0) {
                    for result in results as! [NSManagedObject] {
                        numberofRows = numberofRows + 1
                    }
                }
            } catch {
                
            }
        }
        */
        return List_of_Tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //getData()
        let cell = UITableViewCell()
        let task = List_of_Tasks[indexPath.row]
        cell.textLabel?.text = task.0 + " Priority: \(task.1)"
    
        return cell
    }
    
    func getData() {
        enum PathChoice {
            case store
            case retrieve
            case update
        }
        let path = PathChoice.retrieve
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        var new_list : [(String,Int)] = []
        if (path == PathChoice.retrieve) {
            var request = NSFetchRequest<NSFetchRequestResult>(entityName: "Task")
            request.returnsObjectsAsFaults = false
            do {
                let results = try context.fetch(request)
                if (results.count > 0) {
                    for result in results as! [NSManagedObject] {
                        var task_name = result.value(forKey: "name") as? String
                        var priority = result.value(forKey: "priority") as? Int
                        new_list.append((task_name!, priority!))
                        //var new_structure = Task(task_name: task_name!, priority: priority!)
                        //List_of_Tasks.append(new_structure)
                    }
                }
                
            } catch {
                
            }
            
        }
        List_of_Tasks = new_list
        sortData()
        //print(task_name! + " has priority of \(priority)")

    }
    
    
    func sortData() {
        List_of_Tasks.sort{ $0.1 < $1.1 }
        
        /*
            for i in 1..<sortedAboveIndex {
                if (sortedArray[i - 1].1 > sortedArray[i].1) {
                    sortedArray.exchangeObjectAtIndex(i, withObjectAtIndex: i-1)
                    lastSwapIndex = i
                }
            }
            sortedAboveIndex = lastSwapIndex
            
        } while (sortedAboveIndex != 0)
        */
    }
    
    /*
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        if editingStyle == .delete {
            let task = Task[indexPath.row]
            context.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).savedContext()
            
            
            do {
                getData()
            }
            catch {
                print("Fetching Failed")
            }
        }
        tableView.reloadData()
    }
    */
}



